<?php
    $koneksi = mysqli_connect("localhost","root","","sclass");
    if (mysqli_connect_error()) {
        echo "koneksi Database Gagal : " .mysqli_connect_error();    
    }
?>