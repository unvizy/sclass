<?php
include "koneksi.php";
$fullname = $_POST['fullname'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = md5($_POST['password']);
$passwordConfirm = md5($_POST['passwordConfirm']);
$level = $_POST["level"];


$user_check = mysqli_query($koneksi, "SELECT * FROM akun WHERE email='$email' AND password='$password'");
$row = mysqli_fetch_array($user_check);

$data = $_POST;

if ($data['password'] !== $data['passwordConfirm']) {
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('KONFIRMASI PASSWORD TIDAK SESUAI');
    window.location.href='register.php';
    </script>");   
}
elseif ($row > 0){
    echo ("<script LANGUAGE='JavaScript'>
        window.alert('Maaf Data Anda Telah Digunakan');
        window.location.href='register.php';
        </script>");
    } else {
        $query_sql = mysqli_query($koneksi,"INSERT INTO akun (fullname, email, username, password, level) VALUES ('$fullname' , '$email', '$username', '$password', '$level')");
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('Anda berhasil daftar ! Silahkan Login');
        window.location.href='login.php';
        </script>");
        
    }



?>