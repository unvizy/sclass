<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Halaman Admin</title>
</head>

<body align="center">
		<h2>Halaman Admin</h2>

		<br />

		<!-- cek apakah sudah login -->
		<?php
		session_start();

		//jika session username belum dibuat, atau session username kosong
		if (!isset($_SESSION['admin'])) {
			//redirect ke halaman login
			header('location:../login.php');
		}

		include('../koneksi.php');
		$query = mysqli_query($koneksi, "SELECT * FROM akun INNER JOIN user_lv ON user_lv.level = akun.level
        WHERE username='$_SESSION[admin]' ");
		while ($fetch = mysqli_fetch_array($query)) { ?>
			<h4>Selamat datang, <?php echo $fetch['username']; ?>! Anda login sebagai Admin.</h4>
		<?php } ?>
		<br />

		<a href="../logout.php">LOGOUT</a>
</body>

</html>