<?php
session_start();
include "koneksi.php";
$username = mysqli_real_escape_string($koneksi, $_POST["username"]);
$password = mysqli_real_escape_string($koneksi,md5($_POST['password']));

$data = mysqli_query($koneksi, "SELECT * FROM akun WHERE username='$username' AND password='$password'");

$row = mysqli_fetch_array($data);

if ($row['level'] == 1) {
    $_SESSION['admin'] = $username;
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Selamat Datang Di Halaman Admin !');
    window.location.href='admin/index.php';
    </script>");
} elseif ($row['level'] == 2) {
    $_SESSION['siswa'] = $username;
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Selamat Datang Di Halaman Siswa !');
    window.location.href='siswa/index.php';
    </script>");
} else {
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Ada Kesalahan ! Harap Periksa !');
    window.location.href='login.php';
    </script>");
}